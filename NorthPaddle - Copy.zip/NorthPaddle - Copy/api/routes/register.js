
const{ registerController } = require('../controllers/registerController');
const{ checkUser } = require('../controllers/registerController')
const express = require('express');
const router = express.Router();
router.post("/register", registerController);
router.post("/checkUser",  checkUser);

module.exports = router;