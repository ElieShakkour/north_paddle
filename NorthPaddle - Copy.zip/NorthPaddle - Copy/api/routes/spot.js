const express = require('express');
const authenticateToken = require('./middleware');
const{ addSpotController,
    reserveSpotController,
    deleteSpotController,
    getAvailableSpotsController,
    getBookedSpotsController} = require('../controllers/spotController');


    const router = express.Router();
    router.post("/spot/addspot",authenticateToken, addSpotController);
    router.post("/spot/reservespot",authenticateToken, reserveSpotController);
    router.post("/sopt/deletespot",authenticateToken, deleteSpotController);
    router.get("/spot/getavailablespots",authenticateToken, getAvailableSpotsController);
    router.get("/sopt/getbookedspots",authenticateToken, getBookedSpotsController);
 
    module.exports = router;
    
    