const express = require('express');
require('dotenv').config();
const cors = require('cors');
const bodyParser = require('body-parser');
const http = require('http');
const path = require('path');
const app = express();
const port = process.env.APP_PORT;
const axios = require('axios');
const currentDirectory = __dirname;
const buildDirectory = path.join(currentDirectory, 'build');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
let server = http.createServer(app); 
app.use(express.static(buildDirectory));   

const auth = require('./routes/auth');
const register = require('./routes/register');
const spot = require('./routes/spot');
app.use('/api/auth', auth);
app.use('/api', register);
app.use('/api', spot);

app.get('/', (req, res) => {
    res.send({ message: 'welcome to north paddle ' });
  });

  server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
  