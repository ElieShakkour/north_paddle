const {  addSpot,reserveSpot,deleteSpot,getBookedSpots,getAvailableSpots} = require ("../services/spotService");


const addSpotController = async(req,res)=>{
    const spot = req.body;
    if(!spot){
        return res.status(401).json({message:"missing data"})
    }
    const result = await addSpot(spot);
    if(result.status ===200){
        return res.status(200).json({message: result.message})
    }
    return res.status(401).json({message:"Unauthorized"})

}
const reserveSpotController = async(req,res)=>{
    const spot = req.body;
    if(!spot){
        return res.status(401).json({message:"missing data"})
    }
    const result = await reserveSpot(spot);
    if(result.status ===200){
        return res.status(200).json({message: result.message})
    }
    return res.status(401).json({message:"Unauthorized"})

}
const deleteSpotController = async(req,res)=>{
    const spot = req.body;
    if(!spot){
        return res.status(401).json({message:"missing data"})
    }
    const result = await deleteSpot(spot);
    if(result.status ===200){
        return res.status(200).json({message: result.message})
    }
    return res.status(401).json({message:"Unauthorized"})

}
const getAvailableSpotsController = async(req,res)=>{
    const spot = req.body;
  
    const result = await getAvailableSpots(spot);
    if(result.status ===200){
        return res.status(200).json({message: result.message,spots:result.spots})
    }
    return res.status(401).json({message:"Unauthorized"})

}

const getBookedSpotsController = async(req,res)=>{
    const spot = req.body;
  
    const result = await getBookedSpots(spot);
    if(result.status ===200){
        return res.status(200).json({message: result.message,spots:result.spots})
    }
    return res.status(401).json({message:"Unauthorized"})

}


module.exports = {
    addSpotController,
    reserveSpotController,
    deleteSpotController,
    getBookedSpotsController,
    getAvailableSpotsController
}