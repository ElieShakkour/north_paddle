const {query} = require('../database/db');

const register = async (data)=>{
    const {name,familyName,email,password,phone} = data;
    const sql = `Insert INTO users (user_name,user_familyName,user_email,user_password,user_phoneNumber) VALUES (?,?,?,?,?)`;
    try{
        const user = await query(sql,[name,familyName,email,password,phone]);
        if (!user) {
            return { status: 401, message: "cannot Signup with these credentials!" }
        }

        return { status: 200, message: "Successful", user: user }
    } catch (error) {
        return { status: 500, message: "internal error" }
    }
    }
const checkIfPresent = async (data)=>{
  
    const {email} = data;
       const sql =`Select * from users where user_email = ? `
       try{
        const user = await query(sql,[email]);
        if (user.length===0) {
            return { status: 401, message: "Email not found" }
        }
        return { status: 200, message: "Email Found", user: user }
    } catch (error) {
        return { status: 500, message: "internal error" }
    }
}
    module.exports = {
        register,
        checkIfPresent
    }