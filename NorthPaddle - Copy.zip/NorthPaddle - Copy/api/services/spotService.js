const {query} = require('../database/db');

const addSpot = async (data)=>{
    const {spot_date,sport_court} = data;
    const sql = `Insert INTO spot (spot_date,sport_court) VALUES (?,?)`;
    try{
        const spot = await query(sql,[spot_date,sport_court]);
        if (!spot) {
            return { status: 401, message: "cannot add spot" }
        }

        return { status: 200, message: "Successful" }
    } catch (error) {
        return { status: 500, message: "internal error" }
    }
    }

const reserveSpot = async (data)=>{
  
    const {user_id,spot_id} = data;
       const sql =`UPDATE spot SET user_id = ?, spot_reserved = ? WHERE spot_id = ?; `
       try{
        const spot = await query(sql,[user_id,1,spot_id]);
        if (!spot) {
            return { status: 401, message: "cannot reserve spot" }
        }

        return { status: 200, message: "Successful" }
    } catch (error) {
        return { status: 500, message: "internal error" }
    }
}

const deleteSpot = async (data)=>{
  
    const {spot_id} = data;
       const sql =`DELETE FROM spot WHERE spot_id =? ; `
       try{
        const spot = await query(sql,[spot_id]);
        if (!spot) {
            return { status: 401, message: "cannot delete spot" }
        }

        return { status: 200, message: "Successful" }
    } catch (error) {
        return { status: 500, message: "internal error" }
    }
}

const getAvailableSpots = async ()=>{
  
    const sql =`SELECT FROM spot WHERE spot_reserved =? ; `
    try{
     const spot = await query(sql,[0]);
     if (!spot) {
         return { status: 401, message: "cannot get spots" }
     }
     if(spot.length===0){
         return { status: 200, message: "No available spots",spots:[] } 
     }
     return { status: 200, message: "Successful",spots:spot }
 } catch (error) {
     return { status: 500, message: "internal error" }
 }
}






const getBookedSpots = async ()=>{
  
       const sql =`SELECT FROM spot WHERE spot_reserved =? ; `
       try{
        const spot = await query(sql,[1]);
        if (!spot) {
            return { status: 401, message: "cannot get spots" }
        }
        if(spot.length===0){
            return { status: 200, message: "No booked spots",spots:[] } 
        }
        return { status: 200, message: "Successful",spots:spot }
    } catch (error) {
        return { status: 500, message: "internal error" }
    }
}



    module.exports = {
        addSpot,
        reserveSpot,
        deleteSpot,
        getAvailableSpots,
        getBookedSpots
    }