import http from "../http-common";
import { getToken } from "../UTILS/localStorageUtils";
const authenticate = (user) => 
{
    return http.post(`/auth/authenticate`, user);
}



const register = (user) => 
{

    return http.post(`/register`, user);
}

const checkUser = (user) => 
{
    return http.post(`/checkUser`, user);
}

const UserService = {
    authenticate,
    register,
    checkUser,

}


export default UserService;