import logo from './logo.svg';
import './App.css';
import Login from './Pages/login';
import Signup from './Pages/Signup';
import WelcomePage from './Pages/WelcomePage';
import { getLocalStorageUser,setLocalStorageUser } from './UTILS/localStorageUtils';
import { BrowserRouter as Router, Link, Route, Routes,useNavigate } from 'react-router-dom';
function App() {


  const handleLogin = async () => {
 

  };

  return (
    <div className="App">
      <Router>  
      <Routes>
            <Route path="/" element={<WelcomePage />} />
            <Route path="/signin" element={<Login onLogin={handleLogin} />} />
            <Route path="/signup" element={<Signup onLogin={handleLogin} />} />
      
          </Routes>
          

      </Router>
    </div>
  );
}

export default App;
