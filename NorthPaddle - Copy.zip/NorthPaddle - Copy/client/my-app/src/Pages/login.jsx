import React, {useEffect, useState} from "react"

import UserService from "../services/UserService";
import { setLocalStorageUser} from "../UTILS/localStorageUtils";
import { toast } from "react-toastify";
import { getLocalStorageUser } from "../UTILS/localStorageUtils";
import '../App.css';
import { useNavigate } from 'react-router-dom';

const Login = ({onLogin,onVolunteerLogin})=>{

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();


    const handleLogin = async(e) =>{

      e.preventDefault();
        if(email !== '' && password !== ''){
            const user = {
                email: email,
                password
            }
      


           let result = await UserService.authenticate({user}).catch(error=>{
                toast.error("WRONG USERNAME/PASSWORD");
                reset();
            });
           
        
            if(result?.data?.message === "Successful"){
                let authenticatedUser = result?.data?.user;
                authenticatedUser.token = result?.data?.token;
                setLocalStorageUser(authenticatedUser);


                navigate('/');
          
            }
        }
    
    
    }
    const reset = () => {
        setEmail("");
        setPassword("");
    }

    return (
      <div className="login-container">
        <form>
        <div className="login-card">
          <h2>Signin</h2>
          <hr className="dotted-line" />
          <div className="form-group">
          
            <input
              type="text"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          
          <div className="form-group">
          
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
      
          <button
            className="btn btn-sm text-light fw-bold"
            style={{ backgroundColor: "#3498db" }}
            onClick={handleLogin}
          >
            Login
          </button>
        </div>
        </form>
      </div>
    );
    
};

export default Login;