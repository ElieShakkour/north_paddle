import React, { useEffect, useState } from "react";
import UserService from "../services/UserService";
import { setLocalStorageUser } from "../UTILS/localStorageUtils";
import "../App.css";
import { toast } from "react-toastify";
import { MDBBtn,MDBContainer,MDBRow,MDBCol,MDBCard,MDBCardBody,MDBCardImage,MDBInput,MDBIcon,MDBCheckbox,} from "mdb-react-ui-kit";
import axios from "axios";

const Signup = ({ }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [familyName, setFamilyName] = useState("");
  const [phone, setPhone] = useState("");

  const handleSignup = async (e) => {
    e.preventDefault();

    if (name !== "" && email !== "" && password !== "" && familyName !== "" && phone !== ""  ) {
      const user = {
        email: email,
        password: password,
        name: name,
        familyName: familyName,
        phone: phone,
      };
      console.log(user);
      const checkIfUserAvailable = await UserService.checkUser({ user });
      if (checkIfUserAvailable.data.message === "Email not found") {
        const result = await UserService.register({ user }).catch((error) => {
          alert(error.message);
          reset();
        });
      
        if (result?.data?.message === "Successful") {
          console.log(result)
          let authenticatedUser = result?.data?.user;
          authenticatedUser.token = result?.data?.token;
          setLocalStorageUser(authenticatedUser);
    
      }

      } else {
        toast.error("Email Already Used");
        reset();
      }
    } else {
      toast.error("Please enter all your information");
      reset();
    }
  };




  const reset = () => {
    setEmail("");
    setPassword("");
  };

  return (
    <MDBContainer className="mt-5">
    
  
      <MDBRow className="justify-content-center">
        <MDBCol md="6">
          <MDBCard>
            <MDBCardBody className="p-4">
   
              <form>
          
                <MDBInput
                  label="Your Name"
                  size="lg"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
       <MDBInput
                  label="Your Familyname"
                  size="lg"
                  type="text"
                  value={familyName}
                  onChange={(e) => setFamilyName(e.target.value)}
                />

          <MDBInput wrapperClass="mb-4"label="Your Email" size="lg" id="form2" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
          />
      
          <MDBInput wrapperClass="mb-4" label="Phone" size="lg" id="form4" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)}
          />
          <div className="mb-4 custom-select">
         
          </div>
            <MDBInput
            wrapperClass="mb-4"
            label="Password"
            size="lg"
            id="form6"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          
              </form>
              <button
  className="btn btn-primary w-100 mt-4"
  onClick={handleSignup}
>
  Signup
</button>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
  
     
    </MDBContainer>
  );
};

export default Signup;
