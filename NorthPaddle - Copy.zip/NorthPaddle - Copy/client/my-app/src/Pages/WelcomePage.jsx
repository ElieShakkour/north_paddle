import React, {useEffect, useState} from "react"

const WelcomePage = ({})=>{

 

    return (
      <div className="login-container">
       
      </div>
    );
    
};

export default WelcomePage;